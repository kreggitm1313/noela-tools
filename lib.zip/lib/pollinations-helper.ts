/**
 * Pollinations.ai - Free AI image generation with no API key required
 * Uses their public API for text-to-image generation
 */

interface PollinationsOptions {
  prompt: string
  width?: number
  height?: number
  seed?: number
  model?: 'flux' | 'flux-realism' | 'flux-anime' | 'flux-3d' | 'turbo'
  nologo?: boolean
  enhance?: boolean
}

export async function generateImageWithPollinations(options: PollinationsOptions): Promise<string> {
  const {
    prompt,
    width = 1024,
    height = 1024,
    seed = Math.floor(Math.random() * 1000000),
    model = 'flux-anime',
    nologo = true,
    enhance = true,
  } = options

  try {
    // Pollinations.ai free API - no authentication needed
    const encodedPrompt = encodeURIComponent(prompt)
    const url = `https://image.pollinations.ai/prompt/${encodedPrompt}?width=${width}&height=${height}&seed=${seed}&model=${model}&nologo=${nologo}&enhance=${enhance}`

    console.log('[v0] Generating image with Pollinations.ai:', { prompt, width, height, model })

    const response = await fetch(url, {
      method: 'GET',
    })

    if (!response.ok) {
      throw new Error(`Pollinations API failed: ${response.status}`)
    }

    // Get the image as blob
    const blob = await response.blob()
    
    // Convert to base64
    const arrayBuffer = await blob.arrayBuffer()
    const base64 = Buffer.from(arrayBuffer).toString('base64')
    const mimeType = blob.type || 'image/jpeg'
    
    console.log('[v0] Successfully generated image with Pollinations.ai')
    
    return `data:${mimeType};base64,${base64}`
  } catch (error) {
    console.error('[v0] Pollinations generation error:', error)
    throw error
  }
}

// Helper function with automatic retry
export async function generateWithFallback(
  prompt: string,
  width: number = 1024,
  height: number = 1024
): Promise<string> {
  const models: Array<'flux-anime' | 'flux' | 'turbo'> = ['flux-anime', 'flux', 'turbo']
  
  for (const model of models) {
    try {
      console.log(`[v0] Trying Pollinations with model: ${model}`)
      return await generateImageWithPollinations({
        prompt,
        width,
        height,
        model,
      })
    } catch (error) {
      console.error(`[v0] Model ${model} failed, trying next...`)
      continue
    }
  }
  
  // If all models fail, return placeholder
  console.warn('[v0] All Pollinations models failed, using placeholder')
  return `/placeholder.svg?height=${height}&width=${width}&query=${encodeURIComponent(prompt)}`
}
