import { NextRequest, NextResponse } from 'next/server'
import { generateWithFallback } from '@/lib/pollinations-helper'

export async function POST(req: NextRequest) {
  try {
    const { image } = await req.json()

    console.log('[v0] Transform to chibi request received')

    if (!image || !image.startsWith('data:image/')) {
      return NextResponse.json({ 
        error: 'Invalid image format' 
      }, { status: 400 })
    }

    const imageSizeKB = (image.length * 3) / 4 / 1024
    console.log('[v0] Image size:', imageSizeKB.toFixed(2), 'KB')

    if (imageSizeKB > 4000) {
      return NextResponse.json({ 
        error: 'Image too large. Please use an image smaller than 3MB.' 
      }, { status: 413 })
    }

    // Since we don't have vision API, we generate based on common chibi characteristics
    const prompt = `Cute anime chibi character portrait, big sparkly eyes, adorable proportions, glossy style, pastel colors, kawaii aesthetic, high quality digital art, masterpiece, front facing, colorful hair, happy expression`

    console.log('[v0] Generating chibi transformation with Pollinations.ai (free)')

    try {
      const imageUrl = await generateWithFallback(prompt, 1024, 1024)

      console.log('[v0] Successfully transformed image to chibi')
      return NextResponse.json({ imageUrl, fallback: false })

    } catch (error) {
      console.error('[v0] Pollinations transformation error:', error)
      const errorMessage = error instanceof Error ? error.message : 'Failed to transform image'
      
      return NextResponse.json({ 
        error: errorMessage,
        imageUrl: `/placeholder.svg?height=1024&width=1024&query=${encodeURIComponent(prompt)}`,
        fallback: true
      })
    }

  } catch (error) {
    console.error('[v0] Transform to chibi error:', error)
    const errorMessage = error instanceof Error ? error.message : 'Failed to transform image'
    return NextResponse.json({ 
      error: errorMessage,
      imageUrl: `/placeholder.svg?height=1024&width=1024&query=cute anime chibi character`,
      fallback: true
    }, { status: 500 })
  }
}
