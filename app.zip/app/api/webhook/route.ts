import { NextRequest, NextResponse } from 'next/server'

export async function POST(req: NextRequest) {
  try {
    const body = await req.json()
    
    // Log webhook events from Farcaster
    console.log('[v0] Farcaster webhook received:', body)
    
    // Handle different event types
    const { event, data } = body
    
    switch (event) {
      case 'frame_added':
        console.log('[v0] Frame added by user:', data)
        break
      case 'frame_removed':
        console.log('[v0] Frame removed by user:', data)
        break
      case 'notification':
        console.log('[v0] Notification event:', data)
        break
      default:
        console.log('[v0] Unknown event type:', event)
    }
    
    return NextResponse.json({ success: true })
  } catch (error) {
    console.error('[v0] Webhook error:', error)
    return NextResponse.json({ error: 'Webhook processing failed' }, { status: 500 })
  }
}

export async function GET() {
  // Health check endpoint
  return NextResponse.json({ status: 'ok', service: 'noela-frame-webhook' })
}
