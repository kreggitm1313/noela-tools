import { NextRequest, NextResponse } from 'next/server'
import { generateWithFallback } from '@/lib/pollinations-helper'

export async function POST(req: NextRequest) {
  try {
    const { prompt, style, aspectRatio } = await req.json()

    if (!prompt || prompt.trim().length === 0) {
      return NextResponse.json({ 
        error: 'Prompt is required' 
      }, { status: 400 })
    }

    // Build enhanced prompt based on style
    const stylePrompts = {
      cute: 'cute pastel colors, soft shading, kawaii aesthetic',
      glossy: 'glossy finish, vibrant colors, shiny highlights',
      soft: 'soft dreamy colors, gentle lighting, ethereal atmosphere',
      futuristic: 'futuristic neon colors, holographic elements, cyberpunk aesthetic',
    }

    const enhancedPrompt = `${prompt}, anime chibi style, big sparkly eyes, adorable proportions, ${stylePrompts[style as keyof typeof stylePrompts] || stylePrompts.cute}, high quality digital art, masterpiece`

    console.log('[v0] Generate chibi request:', { prompt, style, aspectRatio })
    console.log('[v0] Enhanced prompt:', enhancedPrompt)

    const dimensions = aspectRatio === '1:1' 
      ? { width: 1024, height: 1024 } 
      : aspectRatio === '16:9' 
      ? { width: 1280, height: 720 } 
      : { width: 720, height: 1280 }

    try {
      const imageUrl = await generateWithFallback(
        enhancedPrompt,
        dimensions.width,
        dimensions.height
      )

      console.log('[v0] Successfully generated chibi image')
      return NextResponse.json({ imageUrl, fallback: false })

    } catch (error) {
      console.error('[v0] Pollinations generation error:', error)
      const errorMessage = error instanceof Error ? error.message : 'Failed to generate chibi'
      
      return NextResponse.json({ 
        error: errorMessage,
        imageUrl: `/placeholder.svg?height=${dimensions.height}&width=${dimensions.width}&query=${encodeURIComponent(enhancedPrompt)}`,
        fallback: true
      })
    }

  } catch (error) {
    console.error('[v0] Generate chibi error:', error)
    const errorMessage = error instanceof Error ? error.message : 'Failed to generate chibi'
    return NextResponse.json({ 
      error: errorMessage,
      imageUrl: `/placeholder.svg?height=1024&width=1024&query=cute chibi character`,
      fallback: true
    }, { status: 500 })
  }
}
