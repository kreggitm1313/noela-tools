import { NextRequest, NextResponse } from 'next/server'
import { callOpenAIWithFallback } from '@/lib/openai-fallback'
import { generateWithFallback } from '@/lib/pollinations-helper'

export async function POST(req: NextRequest) {
  try {
    const { prompt, bannerType } = await req.json()

    if (!prompt || prompt.trim().length === 0) {
      return NextResponse.json({ 
        error: 'Prompt is required' 
      }, { status: 400 })
    }

    console.log('[v0] Generate banner request:', { prompt, bannerType })

    const dimensions = {
      'banner': { width: 1280, height: 720, ratio: '16:9' },
      'header': { width: 1500, height: 500, ratio: '3:1' },
      'dexscreener': { width: 1200, height: 400, ratio: '3:1' },
    }

    const bannerConfig = dimensions[bannerType as keyof typeof dimensions] || dimensions.banner

    const enhancedPrompt = `Professional ${bannerType} design, ${prompt}, Noela Universe aesthetic with blue and white color scheme, clean modern layout, high quality digital art, perfect for social media, wide banner format, no text overlay, ${bannerConfig.ratio} aspect ratio, masterpiece`

    console.log('[v0] Enhanced banner prompt:', enhancedPrompt)

    try {
      const imageUrl = await generateWithFallback(
        enhancedPrompt,
        bannerConfig.width,
        bannerConfig.height
      )

      console.log('[v0] Successfully generated banner using Pollinations.ai')
      return NextResponse.json({ 
        imageUrl,
        dimensions: bannerConfig,
        fallback: false
      })

    } catch (error) {
      console.error('[v0] Pollinations banner generation error:', error)
      const errorMessage = error instanceof Error ? error.message : 'Failed to generate banner'
      
      // Fallback to OpenAI if Pollinations fails
      if (!process.env.OPENAI_API_KEY) {
        console.error('[v0] OPENAI_API_KEY not found in environment variables')
        return NextResponse.json({ 
          error: 'OPENAI_API_KEY not configured. Please add it to your Vercel project environment variables.' 
        }, { status: 500 })
      }

      if (!process.env.OPENAI_API_KEY.startsWith('sk-')) {
        console.error('[v0] Invalid OPENAI_API_KEY format:', process.env.OPENAI_API_KEY.substring(0, 3))
        return NextResponse.json({ 
          error: `Invalid OPENAI_API_KEY format. The key should start with 'sk-' but starts with '${process.env.OPENAI_API_KEY.substring(0, 3)}...'. You may have set HF_API_KEY instead of OPENAI_API_KEY.` 
        }, { status: 500 })
      }

      const primaryPayload = {
        model: 'dall-e-3',
        prompt: enhancedPrompt,
        n: 1,
        size: '1792x1024',
        quality: 'hd',
      }

      const fallbackPayload1 = {
        ...primaryPayload,
        quality: 'standard', // Try standard quality first
      }

      const fallbackPayload2 = {
        model: 'dall-e-2',
        prompt: enhancedPrompt.substring(0, 1000),
        n: 1,
        size: '1024x1024',
      }

      try {
        const response = await callOpenAIWithFallback(
          'https://api.openai.com/v1/images/generations',
          primaryPayload,
          [fallbackPayload1, fallbackPayload2]
        )

        if (!response.ok) {
          const errorText = await response.text()
          console.error('[v0] OpenAI API error response:', errorText)
          console.error('[v0] Status code:', response.status)
          
          let errorMessage = 'Failed to generate banner'
          try {
            const errorData = JSON.parse(errorText)
            errorMessage = errorData.error?.message || errorMessage
            
            if (errorData.error?.code === 'invalid_api_key') {
              errorMessage = 'Invalid OpenAI API key. Please verify your OPENAI_API_KEY in Vercel environment variables.'
            } else if (errorData.error?.code === 'insufficient_quota' || errorData.error?.code === 'billing_hard_limit_reached') {
              errorMessage = 'OpenAI quota exceeded. Please add credits to your account or try again later.'
            } else if (errorData.error?.code === 'content_policy_violation') {
              errorMessage = 'Content policy violation. Please try a different prompt.'
            }
          } catch (e) {
            errorMessage = errorText.substring(0, 200)
          }
          
          console.log('[v0] Returning fallback placeholder image due to API failure')
          return NextResponse.json({ 
            imageUrl: `/placeholder.svg?height=${bannerConfig.height}&width=${bannerConfig.width}&query=${encodeURIComponent(prompt)}`,
            dimensions: bannerConfig,
            fallback: true,
            message: errorMessage
          })
        }

        let data
        try {
          data = await response.json()
        } catch (parseError) {
          console.error('[v0] Failed to parse response as JSON:', parseError)
          // Return fallback if we can't parse the response
          return NextResponse.json({ 
            imageUrl: `/placeholder.svg?height=${bannerConfig.height}&width=${bannerConfig.width}&query=${encodeURIComponent(prompt)}`,
            dimensions: bannerConfig,
            fallback: true,
            message: 'API returned invalid response format'
          })
        }

        console.log('[v0] Successfully generated banner using OpenAI')
        return NextResponse.json({ 
          imageUrl: data.data[0].url,
          dimensions: bannerConfig,
          fallback: false
        })

      } catch (fetchError) {
        console.error('[v0] Fetch error:', fetchError)
        
        const errorMessage = fetchError instanceof Error ? fetchError.message : 'Network error occurred'
        return NextResponse.json({ 
          imageUrl: `/placeholder.svg?height=${bannerConfig.height}&width=${bannerConfig.width}&query=${encodeURIComponent(prompt)}`,
          dimensions: bannerConfig,
          fallback: true,
          message: errorMessage
        })
      }

    }

  } catch (error) {
    console.error('[v0] Generate banner error:', error)
    const errorMessage = error instanceof Error ? error.message : 'Failed to generate banner'
    
    const bannerConfig = { width: 1280, height: 720, ratio: '16:9' }
    return NextResponse.json({ 
      error: errorMessage,
      imageUrl: `/placeholder.svg?height=${bannerConfig.height}&width=${bannerConfig.width}&query=professional banner design`,
      dimensions: bannerConfig,
      fallback: true
    }, { status: 500 })
  }
}
