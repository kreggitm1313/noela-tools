import { NoelaFrameApp } from '@/components/noela-frame-app'

export default function Page() {
  return <NoelaFrameApp />
}
