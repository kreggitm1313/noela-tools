import type { Metadata } from 'next'
import { Geist, Geist_Mono } from 'next/font/google'
import { Analytics } from '@vercel/analytics/next'
import { Toaster } from '@/components/ui/toaster'
import './globals.css'

const _geist = Geist({ subsets: ["latin"] });
const _geistMono = Geist_Mono({ subsets: ["latin"] });

export const metadata: Metadata = {
  title: 'Noela Frame - Create Cute Anime Chibi Art',
  description: 'Transform photos into cute anime chibi art, generate AI chibi characters, and create social media banners. Part of the Noela Universe.',
  generator: 'v0.app',
  other: {
    'fc:frame': 'vNext',
    'fc:frame:image': 'https://noela-frame.vercel.app/og-image.png',
    'fc:frame:button:1': 'Launch Noela Frame',
    'fc:frame:button:1:action': 'link',
    'fc:frame:button:1:target': 'https://noela-frame.vercel.app',
  },
  icons: {
    icon: [
      {
        url: '/icon-light-32x32.png',
        media: '(prefers-color-scheme: light)',
      },
      {
        url: '/icon-dark-32x32.png',
        media: '(prefers-color-scheme: dark)',
      },
      {
        url: '/icon.svg',
        type: 'image/svg+xml',
      },
    ],
    apple: '/apple-icon.png',
  },
  openGraph: {
    title: 'Noela Frame - Create Cute Anime Chibi Art',
    description: 'Transform photos into cute anime chibi art, generate AI chibi characters, and create social media banners.',
    images: ['/og-image.png'],
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Noela Frame - Create Cute Anime Chibi Art',
    description: 'Transform photos into cute anime chibi art, generate AI chibi characters, and create social media banners.',
    images: ['/og-image.png'],
  },
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="en">
      <head>
        <script
          type="application/json"
          id="farcaster-manifest"
          dangerouslySetInnerHTML={{
            __html: JSON.stringify({
              version: '1',
              imageUrl: 'https://noela-frame.vercel.app/og-image.png',
              button: {
                title: '✨ Launch Noela Frame',
                action: {
                  type: 'launch_frame',
                  name: 'Noela Frame',
                  url: 'https://noela-frame.vercel.app',
                  splashImageUrl: 'https://noela-frame.vercel.app/splash.png',
                  splashBackgroundColor: '#3b82f6',
                },
              },
            }),
          }}
        />
      </head>
      <body className={`font-sans antialiased`}>
        {children}
        <Toaster />
        <Analytics />
      </body>
    </html>
  )
}
